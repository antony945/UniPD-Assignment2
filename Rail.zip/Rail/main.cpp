#include <iostream>
#include "Railway.h"
using namespace std;

// File di test
int main() {
    Railway myRailway{"../line_description.txt", "../timetables_1.txt", "../output_1.txt"};
    myRailway.printInfo();
    myRailway.daySimulation();
    return 0;
}
